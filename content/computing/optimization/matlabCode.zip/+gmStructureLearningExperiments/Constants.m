classdef Constants
properties(Static = true)
    LOG_PATH = '/u/vvasuki/projectsSvn/graphicalModels/log/';
    TMP_PATH = [gmStructureLearningExperiments.Constants.LOG_PATH 'tmp/'];
end

methods(Static = true)
function testClass
    display 'Class definition is ok';
end
end
end