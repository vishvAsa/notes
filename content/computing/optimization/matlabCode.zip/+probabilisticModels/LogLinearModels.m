classdef LogLinearModels
methods(Static=true)
function [beta] = logisticRegressionl1Reg(y, Samples, lambda)
% Model: Pr(y=1) = exp(\beta_0 + \sum_i beta_i x_i)/(1+exp(\beta_0 + \sum_i beta_i x_i))
%INPUT: RESPONSE Y, PREDICTOR Samples, PENALTY LAMBDA
%OUTPUT: COEFFICIENTS BETA.
% Uses code by Boyd.
    Samples = Samples';
    y = y';
    n = size(Samples,1);
    p = size(Samples,2);
    
    Xfile = sprintf('/tmp/Samples-%d-%d-%.2f',p,n,lambda);
    yfile = sprintf('/tmp/y-%d-%d-%.2f',p,n,lambda);
    modelfile = sprintf('/tmp/model-%d-%d-%.2f',p,n,lambda);
    
    mmwrite(Xfile,Samples);
    mmwrite(yfile,y);
    system(sprintf('/public/linux/graft/optimization/l1_logreg-0.8.2-i686-pc-linux-gnu/l1_logreg_train -q -s %s %s %f %s',Xfile,yfile,lambda,modelfile));
    beta = full(mmread(modelfile));
    % beta = beta(2:end);
    % fprintf('lambda %d \n', lambda);
    % beta'
end

function [beta] = logisticRegressionl1RegWithValidation(y, Samples)
    % error('Testing incomplete');
    import probabilisticModels.*;
    import statistics.*;
    l = [0:0.01:.1];
    lambdaRange = l./(1-l);
    numSplits = 3;
    
    learnerParametrized = @(X1, y1, lambda)Classifier.classifierFromParameters(@LogLinearModels.classifyLogistic, LogLinearModels.logisticRegressionl1Reg(y1, X1, lambda));
    badnessFn = @(lambda) -ClassificationEvaluation.getGeneralizationAbilityClassificationFromCrossValidation(Samples, y, @(X1, y1)learnerParametrized(X1, y1, lambda), numSplits);
    
    [objMin, lambdaBest] = optimization.DescentMethods.discreteSequentialMinimization({lambdaRange}, badnessFn);
    
    beta = LogLinearModels.logisticRegressionl1Reg(y, Samples, lambdaBest);
    fprintf('logisticRegressionl1RegWithValidation: Found beta!\n');
    beta'
end

function label = classifyLogistic(x, beta, bIgnoreBiasTerm)
% Model: Pr(y=1) = exp(\beta_0 + \sum_i beta_i x_i)/(1+exp(\beta_0 + \sum_i beta_i x_i))
    % beta'
    if(exist('bIgnoreBiasTerm') && bIgnoreBiasTerm)
        beta = beta(2:end);
    end
    if (numel(x) == numel(beta))
        label = (dot(x,beta) >= 0);
    elseif (numel(x) == numel(beta) - 1)
        label = ((dot(x, beta(2:end)) + beta(1)) >= 0);
    else
        error('Invalid input!');
    end
end

function labels = classifyLogisticEnMasse(Samples, beta)
% Model: Pr(y=1) = exp(\beta_0 + \sum_i beta_i x_i)/(1+exp(\beta_0 + \sum_i beta_i x_i))
    import probabilisticModels.*;
    labels = MatrixFunctions.functionalToEachColumn(Samples, @(x)LogLinearModels.classifyLogistic(x, beta));
end

function testClass
    display 'Class definition is ok';
end

end
end
