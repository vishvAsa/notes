classdef BinaryClassificationTest
methods(Static=true)
function [EdgePotentials_1, EdgePotentials_0, AdjMatrix_1, AdjMatrix_0,  NodePotentials_1,  NodePotentials_0] = makeTestIsingModel(numNodes, topology)
    import probabilisticModels.*;
    
    degmax = ceil(0.1 * numNodes);
    couplingStrength = min(0.1,2.5/degmax);
    couplingType = 'mixed';
    
    [AdjMatrix_0, NodePotentials_0, EdgePotentials_0] = DiscreteRVGraphicalModel.getBinaryRVGraphicalModel(topology, numNodes, degmax, couplingStrength, couplingType);
    
    [AdjMatrix_1, NodePotentials_1, EdgePotentials_1] = DiscreteRVGraphicalModel.getBinaryRVGraphicalModel(topology, numNodes, degmax, couplingStrength, couplingType);
end

function [Samples, y] = getSamples(EdgePotentials_1, EdgePotentials_0, AdjMatrix_1, AdjMatrix_0, NodePotentials_1,  NodePotentials_0, numSamples, Pr_y1, topology)
    import probabilisticModels.*;
    import graph.*;
    Pr_y0 = 1- Pr_y1;
    bIsTree = Graph.isTree(topology);
    
    numY1Samples = ceil(numSamples*Pr_y1);
    Samples_1 = DiscreteRVGraphicalModel.getSamples(AdjMatrix_1, NodePotentials_1, EdgePotentials_1, bIsTree, numY1Samples);
    
    Samples_0 = DiscreteRVGraphicalModel.getSamples(AdjMatrix_0, NodePotentials_0, EdgePotentials_0, bIsTree, numSamples - numY1Samples);
    
    
    Samples = [Samples_0 Samples_1];
    Samples(Samples_0 == 2) = -1;
    y = [zeros(1, numSamples - numY1Samples) ones(1, numY1Samples) ];
end

function discriminativeVsGenerativeL1RegLogistic(numNodes)
    import probabilisticModels.*;
    import statistics.*;
    
    topology = 'star';
    numSamplesTest = 10000;
    Pr_y1 = 0.6;
    
    [EdgePotentials_1, EdgePotentials_0, AdjMatrix_1, AdjMatrix_0, NodePotentials_1,  NodePotentials_0] = BinaryClassificationTest.makeTestIsingModel(numNodes, topology);
    
    samplingFn = @(numSamplesTraining)BinaryClassificationTest.getSamples(EdgePotentials_1, EdgePotentials_0, AdjMatrix_1, AdjMatrix_0, NodePotentials_1,  NodePotentials_0, numSamplesTraining, Pr_y1, topology);
    
    [SamplesTest, yTest] = BinaryClassificationTest.getSamples(EdgePotentials_1, EdgePotentials_0, AdjMatrix_1, AdjMatrix_0, NodePotentials_1,  NodePotentials_0, numSamplesTest, Pr_y1, topology);
    
    numSamplesTrainingRange = [100:100:1500];
    numTrials = 1;
    
    % learner corresponding to logisticRegressionl1RegWithValidation
    learner = @(SamplesTraining, yTraining)Classifier.classifierFromParameters(@LogLinearModels.classifyLogistic, LogLinearModels.logisticRegressionl1RegWithValidation(yTraining, MatrixFunctions.vectorFnToEachColumn(SamplesTraining, @VectorFunctions.mixedQuadraticFeatureMap)));
    
    % learner corresponding to logisticRegressionl1Reg with lambda = 0
    % learner = @(SamplesTraining, yTraining)Classifier.classifierFromParameters(@(x, params)LogLinearModels.classifyLogistic(x, params, true), LogLinearModels.logisticRegressionl1Reg(yTraining, SamplesTraining, 0));
    
    fracMisclassificationValues = ClassificationEvaluation.getSampleComplexity(learner, numSamplesTrainingRange, samplingFn, MatrixFunctions.vectorFnToEachColumn(SamplesTest, @VectorFunctions.mixedQuadraticFeatureMap), yTest, numTrials);
    
    plot(numSamplesTrainingRange, fracMisclassificationValues);
    
end

function testClass
    display 'Class definition is ok';
end

end
end
