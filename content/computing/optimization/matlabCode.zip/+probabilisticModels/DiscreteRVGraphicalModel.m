classdef DiscreteRVGraphicalModel
methods(Static=true)
function Samples = getSamples(model, numSamples)
%   Sample using Mark Schmidt's UGM package. (http://www.cs.ubc.ca/~schmidtm/Software/UGM/small.html)
%   OUTPUT: Samples: numNodes * numSamples array of samples.
    AdjMatrix = model.AdjMatrix;
    NodePotentials = model.NodePotentials;
    EdgePotentials = model.EdgePotentials;
    bIsTree = model.bIsTree;
    
    numStates = size(NodePotentials, 2);
    edgeStruct = UGM_makeEdgeStruct(AdjMatrix, numStates);
    if(bIsTree)
        % display 'Tree sampling: using divide and conquer'
        edgeStruct.maxIter = numSamples;
        Samples = UGM_Sample_Tree(NodePotentials, EdgePotentials, edgeStruct);
    else
%          Samples = UGM_Sample_Exact(nodePot,edgePot,edgeStruct);
        % display 'Approximate sampling: Gibbs'
        burnIn = 1000;
        edgeStruct.maxIter = numSamples;
        Samples = UGM_Sample_Gibbs(NodePotentials, EdgePotentials, edgeStruct, burnIn);
    end
end

function sampleBatches = getSampleBatches(oldSampleBatches, numSamples, numSampleSets, model)
    import probabilisticModels.*;
    if(exist('oldSampleBatches') && (size(oldSampleBatches, 1)>0))
        sampleBatches = oldSampleBatches;
        numOldSamples = size(oldSampleBatches{1}, 2);
        numSampleSets = length(oldSampleBatches);
    else
        sampleBatches = {};
        numOldSamples = 0;
    end
    for sampleBatch = 1:numSampleSets
        numNewSamples = numSamples - numOldSamples;

        if(numNewSamples > 0)
            Samples = DiscreteRVGraphicalModel.getSamples(model, numNewSamples);
            if(numOldSamples>0)
                Samples = [Samples oldSampleBatches{sampleBatch}];
            end
        else
            Samples = oldSampleBatches{sampleBatch};
            Samples = Samples(:, 1:numSamples);
        end
        sampleBatches{sampleBatch} = Samples;
    end
    fprintf('Got %d sets of %d samples! \n', numSampleSets, numSamples);
end

function [model] = getDiscreteRVGraphicalModel(topology, numNodes, degmax, numStates, couplingType, disparityLevel, minCoupling)
%      Process inputs
    import graph.*;
    import probabilisticModels.*;
    if(isempty(couplingType))
        couplingType = 'normal';
    end
    
    function [AdjMatrix, NodePotentials, EdgePotentials] = getFullyIndependentGraphicalModel(topology, numNodes, degmax, numStates)
        if(isempty(degmax))
            degmax = (numNodes - 1);
        end

        AdjMatrix = graph.Graph.getGraph(topology, numNodes, degmax);

        NodePotentials = ones(numNodes, numStates);


        numEdges = sum(sum(triu(AdjMatrix)));
        EdgePotentials = ones(numStates, numStates, numEdges);
    end

    [AdjMatrix, NodePotentials, EdgePotentials] = getFullyIndependentGraphicalModel(topology, numNodes, degmax, numStates);
    numEdges = size(EdgePotentials, 3);
    for(edge = 1:numEdges)
        switch couplingType
            case 'normal'
                EdgeCouplingTemplate = randn(numStates-1)*disparityLevel;
            case 'uniform'
                EdgeCouplingTemplate = rand(numStates-1)*disparityLevel;
        end
        
        EdgeCouplingTemplate = minCoupling+EdgeCouplingTemplate;
        EdgePotentials(:, :, edge) = exp([EdgeCouplingTemplate zeros(numStates-1, 1); zeros(1, numStates-1), 0]);
    end
    model.AdjMatrix = AdjMatrix;
    model.NodePotentials = NodePotentials;
    model.EdgePotentials = EdgePotentials;
    model.topology = topology;
    model.bIsTree = Graph.isTree(topology);
    model.couplingRange = [minCoupling minCoupling+disparityLevel];
    model.couplingType = couplingType;
end

function [AdjMatrix, NodePotentials, EdgePotentials] = getBinaryRVGraphicalModel(topology, numNodes, degmax, couplingStrength, couplingType)
    import probabilisticModels.*;
    numStates = 2;
    
    [AdjMatrix, NodePotentials, EdgePotentials] = DiscreteRVGraphicalModel.getFullyIndependentGraphicalModel(topology, numNodes, degmax, numStates);
    numEdges = size(EdgePotentials, 3);
    
    EdgePotentialTemplatePositive = 2.^(couplingStrength*[1 -1; -1 1]);
    EdgePotentialTemplateNegative = 2.^(couplingStrength*[-1 1; 1 -1]);
    
    EdgePotentialFractions = ones(1, numEdges);
    
    if(~isempty(findstr(topology, 'star')))
        rho = min(0.1,2.5/degmax);
        sig = eye(numNodes);
        for(s = 1:numNodes)
            if(AdjMatrix(1,s) ~= 0)
                sig(1,s) = rho;
                sig(s,1) = rho;
                
                for(t = 1:numNodes)
                    if((t ~= s) && (AdjMatrix(1,t) ~= 0))
                        sig(s,t) = rho^2;
                        sig(t,s) = rho^2;
                    end
                end
            end
        end
        EdgePotentialFractionsStar = AdjMatrix.*inv(sig);
        EdgePotentialFractionsStar = EdgePotentialFractionsStar(1,:);
        EdgePotentialFractions = EdgePotentialFractionsStar(EdgePotentialFractionsStar ~= 0);
    end

    
    for(edge = 1:numEdges)
        switch couplingType
            case 'positive'
                EdgePotentialTemplate = EdgePotentialTemplatePositive;
            case 'negative'
                EdgePotentialTemplate = EdgePotentialTemplateNegative;
            case 'mixed'
                if(randomizationUtils.Sample.binaryRandomVariable())
                    EdgePotentialTemplate = EdgePotentialTemplatePositive;
                else
                    EdgePotentialTemplate = EdgePotentialTemplateNegative;
                end
        end
        EdgePotentials(:, :, edge) = EdgePotentialTemplate.^EdgePotentialFractions(edge);
    end
end

function groupIds = getGroupIndices(numNodes, numStates)
% Get variable group indices for the minimal parameters corresponding to one node of a graphical model.
    groupIds = {};
    EmptyMat = false(numStates-1, (numStates-1)*(numNodes-1)+1);
    
    Tmp = EmptyMat;
    Tmp(:,1) = true;
    groupIds{end+1} = Tmp;
    
    for(i=1:numNodes-1)
        Tmp = EmptyMat;
        Tmp(:,1+(i-1)*(numStates-1)+1:1+i*(numStates-1)) = true;
        groupIds{end+1} = Tmp;
    end
end

function [numStates, numNodes] = countStatesAndNodes(EdgeCouplings)
    numStates = size(EdgeCouplings, 1)+1;
    numNodes = (size(EdgeCouplings, 2)-1)/(numStates-1) + 1;
end

function B = getBForUnorthogonalizedFeatures(B1, Rs)
    % If X = QR, then x_{1, :} = q_{1, :}R.
    % So, q^T \beta_q = x^T R^{-1} \beta_q.
    % So, R^{-1} \beta_q = \beta_x
    % This function gets \beta_x from \beta_q.
    import probabilisticModels.*;
    [numStates, numNodes] = DiscreteRVGraphicalModel.countStatesAndNodes(B1);

    B = B1;
    for(node = 1:numNodes-1)
        nBegin = (node-1)*(numStates-1)+1+1;
        Tmp = Rs{node}\B1(:, nBegin:nBegin+(numStates-1)-1)';
        B(:, nBegin:nBegin+(numStates-2)) = Tmp';
    end
end

function B = getBForOrthogonalizedFeatures(B1, Rs)
    % This is the inverse of getBForUnorthogonalizedFeatures. See comments for that function.
    % This function gets \beta_q from \beta_x.
    import probabilisticModels.*;
    [numStates, numNodes] = DiscreteRVGraphicalModel.countStatesAndNodes(B1);

    B = B1;
    for(node = 1:numNodes-1)
        nBegin = (node-1)*(numStates-1)+1+1;
        Tmp = Rs{node}*B1(:, nBegin:nBegin+(numStates-1)-1)';
        B(:, nBegin:nBegin+(numStates-2)) = Tmp';
    end
end

function adjMatrixRow = getNeighborsFromEdgeCouplings(node, EdgeCouplings, edgeCouplingCutoff, Rs)
%   INPUT: EdgeCouplings : numStates * numStates * numNodes matrix or (numStates-1)*(numStates-1)(numNodes-1)+1 matrix.
%      Process input
    import probabilisticModels.*;
    if(~exist('edgeCouplingCutoff'))
        edgeCouplingCutoff = 0;
    end
    
    if(length(size(EdgeCouplings)) == 2)
        bMinimalParametrization = true;
        [numStates, numNodes] = DiscreteRVGraphicalModel.countStatesAndNodes(EdgeCouplings);
        groupIds = DiscreteRVGraphicalModel.getGroupIndices(numNodes, numStates);
        if(exist('Rs'))
            EdgeCouplings = DiscreteRVGraphicalModel.getBForUnorthogonalizedFeatures(EdgeCouplings, Rs);
        end
    else
        bMinimalParametrization = false;
    end
    
    if(isempty(edgeCouplingCutoff))
        edgeCouplingCutoff = 10^-4;
    end
    adjMatrixRow = zeros(1, numNodes);
    potentialNeighbors = [1:node-1, node+1:numNodes];
    for(i = 1:numNodes-1)
        j = potentialNeighbors(i);
        if(bMinimalParametrization)
            NbdEdgeCouplings = EdgeCouplings(groupIds{1+i});
        else
            NbdEdgeCouplings = EdgeCouplings(:, :, j);
        end
        NbdEdgeCouplings = NbdEdgeCouplings(:);
        if(any(abs(NbdEdgeCouplings) > edgeCouplingCutoff))
            adjMatrixRow(1, j) = 1;
        end
    end
end

function AdjMatrix = getAdjMatrixFromEdgeCouplings(EdgeCouplings, edgeCouplingCutoff, symmetrificationRule, Rs)
    import probabilisticModels.*;
    if(iscell(EdgeCouplings))
        numNodes = length(EdgeCouplings);
        bMinimalParametrization = true;
    else
        numNodes = size(EdgeCouplings, 3);
        bMinimalParametrization = false;
    end
    for(node = 1:numNodes)
        if(bMinimalParametrization)
            NbdEdgeCoupling = EdgeCouplings{node};
        else
            NbdEdgeCoupling = EdgeCouplings(:,:,:, node);
        end
        if(~exist('Rs'))
            AdjMatrix(node, :) = DiscreteRVGraphicalModel.getNeighborsFromEdgeCouplings(node, NbdEdgeCoupling, edgeCouplingCutoff, numNodes);
        else
            AdjMatrix(node, :) = DiscreteRVGraphicalModel.getNeighborsFromEdgeCouplings(node, NbdEdgeCoupling, edgeCouplingCutoff, numNodes, Rs);
        end
    end
    AdjMatrix = sparse(AdjMatrix);
    
    if(~exist('symmetrificationRule'))
        return;
    end
    
    if(strcmp(symmetrificationRule, '|'))
        AdjMatrix = AdjMatrix | AdjMatrix';
        return;
    end
    if(strcmp(symmetrificationRule, '&'))
        AdjMatrix = AdjMatrix & AdjMatrix';
    end
    
end

function [designMatrixPartBatches, RBatches] = getDesignMatrixPartBatches(sampleBatches, numStates, bGroupOrthogonalize)
    import probabilisticModels.*;

    designMatrixPartBatches = {};
    RBatches = {};
    numSampleSets = length(sampleBatches);

    for(sampleSet = 1:numSampleSets)
        Samples = sampleBatches{sampleSet};
        [designMatrixParts Rs] = DiscreteRVGraphicalModel.getDesignMatrixParts(Samples, numStates, bGroupOrthogonalize);
        designMatrixPartBatches{end+1} = designMatrixParts;
        RBatches{end+1} = Rs;
    end
end

function [designMatrixParts Rs] = getDesignMatrixParts(Samples, numStates, bGroupOrthogonalize)
    designMatrixParts = {};
    Rs = {};
    numNodes = size(Samples, 1);
    values = 1:numStates-1;
    if(~exist('bGroupOrthogonalize'))
        bGroupOrthogonalize = true;
    end
    for i=1:numNodes
        X = VectorFunctions.getIndicatorMatrixFromVector(Samples(i,:), values);
        if(bGroupOrthogonalize)
            [Q, R] = qr(double(X), 0);
            designMatrixParts{i} = Q;
            Rs{i} = R;
        else
            designMatrixParts{i} = X;
        end
    end
end

function avgNegLogPseudoLikelihood = getAvgNegLogPseudoLikelihood(Samples, EdgeCouplings, designMatrixParts)
    import probabilisticModels.*;
    [numNodes, numSamples] = size(Samples);
    if(exist('designMatrixParts'))
        bMinimalParametrization = true;
    else
        bMinimalParametrization = false;
    end
    avgNegLogPseudoLikelihood = 0;
    
    for(node=1:numNodes)
        if(bMinimalParametrization)
            [X, y] = DiscreteRVGraphicalModelLearner.getObservationsForLogisticRegression(designMatrixParts, Samples, node);

            negLogLikelihood = LogisticMultiClassL1L2Reg.getAvgNegLogLikelihoodWithDerivatives(X, y, EdgeCouplings{node});
        else
            negLogLikelihood = DiscreteRVGraphicalModelNbdLearner.getNegLogLikelihood(Samples, node, EdgeCouplings);
        end
        avgNegLogPseudoLikelihood = avgNegLogPseudoLikelihood + negLogLikelihood;
    end
    
    fprintf(' avgNegLogPseudoLikelihood: %d\n', avgNegLogPseudoLikelihood);
end

function testGetAvgNegLogPseudoLikelihood()
    import probabilisticModels.*;
    import graph.*;
    numStates = 3;
    numNodes = 3;
    degmax = [];
    disparityLevel = 3;
    couplingType = 'uniform';
    topology = 'star';
    bIsTree = 1;
    numSamples = 1000;
    [adjMatrixOriginal, NodePotentials, EdgePotentials] = DiscreteRVGraphicalModel.getDiscreteRVGraphicalModel(topology, numNodes, degmax, numStates, couplingType, disparityLevel);
    Samples = DiscreteRVGraphicalModel.getSamples(adjMatrixOriginal, NodePotentials, EdgePotentials, bIsTree, numSamples);
    EdgeCouplingsActual = zeros(numStates, numStates, numNodes, numNodes);
    EdgeCouplingsActual(:, :, 2, 1) = log(EdgePotentials(:, :, 1));
    EdgeCouplingsActual(:, :, 1, 2) = log(EdgePotentials(:, :, 1));
    EdgeCouplingsActual(:, :, 2, 3) = log(EdgePotentials(:, :, 2));
    EdgeCouplingsActual(:, :, 3, 2) = log(EdgePotentials(:, :, 2));
    
    EdgeCouplingsRandom = rand(numStates, numStates, numNodes, numNodes);
    EdgeCouplingsRandom(:, :, 1, 1) = zeros(numStates);
    EdgeCouplingsRandom(:, :, 2, 2) = zeros(numStates);
    EdgeCouplingsRandom(:, :, 3, 3) = zeros(numStates);
    avgNegLikelihoodActual = DiscreteRVGraphicalModel.getAvgNegLogPseudoLikelihood(Samples, EdgeCouplingsActual);
    avgNegLikelihoodRand = DiscreteRVGraphicalModel.getAvgNegLogPseudoLikelihood(Samples, EdgeCouplingsRandom);
    fprintf('avgNegLikelihoodActual: %d avgNegLikelihoodRand: %d, Test passed? %d \n', avgNegLikelihoodActual, avgNegLikelihoodRand, (avgNegLikelihoodActual < avgNegLikelihoodRand));
end

function testGetBinaryRVGraphicalModel()
    import probabilisticModels.*;
    import graph.*;
    numNodes = 2;
    degmax = [];
    couplingStrength = 0.999;
    couplingType = 'negative';
    topology = 'chain';
    [AdjMatrix, NodePotentials, EdgePotentials] = DiscreteRVGraphicalModel.getBinaryRVGraphicalModel(topology, numNodes, degmax, couplingStrength, couplingType)
    
    numSamples = 15;
    
    bIsTree = Graph.isTree(topology);
    Samples = DiscreteRVGraphicalModel.getSamples(AdjMatrix, NodePotentials, EdgePotentials, bIsTree, numSamples)
    
    fprintf('Expectation: In most samples, nodes connected by an edge disagree in value.');
    
    
end

function test_getNeighborsFromEdgeCouplings
    import probabilisticModels.*;
    numNodes = 3;
    numStates = 3;
    node = 1;
    EdgeCouplings = 10^(-6)*ones(numStates-1, (numNodes-1)*(numStates-1)+1);
    B = [-686.2289e-003     1.1307e-003   841.6886e-006   247.3377e-006  -110.8820e-006;
    82.8713e-003     2.4411e-003    -3.5258e-003  -163.9069e-006   -11.2823e-006];

    
    edgeCouplingCutoff = 10^(-5);
    adjMatrixRow = DiscreteRVGraphicalModel.getNeighborsFromEdgeCouplings(node, B, edgeCouplingCutoff, numNodes);
    % adjMatrixRow
    fprintf('Adj matrix row has %d edges.\n', sum(adjMatrixRow));
end

function test_getAdjMatrixFromEdgeCouplings(symmetrificationRule)
    import probabilisticModels.*;
    numNodes = 3;
    numStates = 3;
    EdgeCouplings{1} = [-444.0689e-003   -59.8775e-003    12.3910e-003   970.1192e-009    -1.5741e-006;
  -538.2851e-003    30.0785e-003    12.6506e-003    -2.0156e-006    81.2118e-009];
    EdgeCouplings{2} =   [702.4542e-003    -4.9410e-006     6.1955e-006   -11.4599e-006     6.1501e-006;
   -75.6870e-003   326.7296e-009     1.6843e-006     6.5202e-006    75.4937e-006];
    EdgeCouplings{3} = [-686.2289e-003     1.1307e-003   841.6886e-006   247.3377e-006  -110.8820e-006;
    82.8713e-003     2.4411e-003    -3.5258e-003  -163.9069e-006   -11.2823e-006];
    edgeCouplingCutoff = 10^-3;
    
    AdjMatrix = DiscreteRVGraphicalModel.getAdjMatrixFromEdgeCouplings(EdgeCouplings, edgeCouplingCutoff, symmetrificationRule);
    AdjMatrix
end

function [numStates, numNodes, Samples] = getTestSamples(numSamples)
    import probabilisticModels.*;
    numStates = 3;
    numNodes = 3;
    AdjMatrix = [0 1 0; 1 0 1; 0 1 0];
    numEdges = 2;
    model.AdjMatrix = AdjMatrix;
    model.NodePotentials = ones(numNodes);
    model.EdgePotentials = ones(numStates, numStates, 2)
    model.bIsTree = true;
    Samples = DiscreteRVGraphicalModel.getSamples(model, numSamples);

end

function testClass
    display 'Class definition is ok';
end

end
end
