classdef DiscreteRVGraphicalModelLearner
methods(Static=true)

function [X, y] = getObservationsForLogisticRegression(designMatrixParts, Samples, node)
    numNodes = size(Samples, 1);
    potentialNeighbors = [1:node-1, node+1:numNodes];
    X = [designMatrixParts{potentialNeighbors}]';
    X = [ones(1, size(X, 2)); X];
    y = Samples(node, :);
end

function [B] = edgeCouplingsFromSamples(Samples, designMatrixParts, Rs, groupL1Factor, EdgeCouplingsInit, optimizationOptions, node)
    import probabilisticModels.*;
    [numStates, numNodes] = DiscreteRVGraphicalModel.countStatesAndNodes(EdgeCouplingsInit);
    groups = DiscreteRVGraphicalModel.getGroupIndices(numNodes, numStates);
    timesElapsed = [];

    fprintf('groupL1Factor: %d\n', groupL1Factor);
    B = EdgeCouplingsInit;
    if(length(Rs)>0)
        B = DiscreteRVGraphicalModel.getBForOrthogonalizedFeatures(B, Rs);
    end

    timer = Timer();
    % profile on
    [X, y] = DiscreteRVGraphicalModelLearner.getObservationsForLogisticRegression(designMatrixParts, Samples, node);

    % B
    % timerTmp = Timer();
    optimizationOptions.bIteratedLestSq = true;
    B = LogisticMultiClassL1L2Reg.getBFromSamplesLagrangian(X, y, groupL1Factor, B, groups, optimizationOptions);
    % timerTmp.endTimer();

    % B
    % B = LogisticMultiClassL1L2Reg.getBFromSamplesLagrangian_cvx(X, y, groupL1Factor, B, groups, optimizationOptions);
    % B

    function B = thresholdParameters(B1, groupsToThreshold, threshold)
        B = B1;
        % B(abs(B)< optimizationOptions.zeroingThreshold) = 0;

        for(groupNum = 1:length(groupsToThreshold))
            group = groupsToThreshold{groupNum};
            B_grp = B(group);
            if(norm(B_grp(:), 'fro') <= threshold)
                B(group) = 0;
            end
        end
    end

    B = thresholdParameters(B, groups(2:end), optimizationOptions.thresholdingFn(groupL1Factor));

    % nllVal = LogisticMultiClassL1L2Reg.getAvgNegLogLikelihoodWithDerivatives(X, y, B);
    % objVal = nllVal + groupL1Factor*LogisticMultiClassL1L2Reg.getL1L2Penalty(B, groups(2:end), groupL1Factor);
    % fprintf(' After thresholding. Objective: %d [nllVal: %d]\n', objVal, nllVal);
    % B

    if(length(Rs)>0)
        B = DiscreteRVGraphicalModel.getBForUnorthogonalizedFeatures(B, Rs);
    end

    % profile report
    % profsave(profile('info'), [gmStructureLearningExperiments.Constants.LOG_PATH 'profilingReport' Timer.getTimeStamp()]);
    timer = timer.endTimer();
    timesElapsed(end+1) = timer.elapsedTime;
    % keyboard

end

function [EdgeCouplings] = isingModeledgeCouplingsFromSamples(Samples, groupL1Factor)
    import probabilisticModels.*;
    xRange = unique(Samples);
    assert(min(xRange ) == -1 && numel(xRange) == 2, 'Improper Samples.');
    [numNodes, numSamples] = size(Samples);
    EdgeCouplings = zeros(numNodes);
    for node = 1:numNodes
        potentialNeighbors = setdiff(1:numNodes,[s]);
        beta = Regression.logisticRegl1Reg(Samples(node, :)', Samples(potentialNeighbors, :)', lambda, lcnst);
        EdgeCouplings(node, potentialNeighbors) = beta(2:end);
    end
    error('Implementation untested');
end


function EdgeCouplings = getInitEdgeCouplings(actualModel, node)
    import probabilisticModels.*;
    EdgePotentials = actualModel.EdgePotentials;
    AdjMatrixOriginal = actualModel.AdjMatrix;
    numStates = size(EdgePotentials, 2);
    numNodes = size(AdjMatrixOriginal, 1);
    bReturnRandomCouplings = false;
    if(bReturnRandomCouplings)
        EdgeCouplings = rand(numStates-1, (numStates-1)*(numNodes-1) + 1);
        return;
    end
    
    edgeStruct = UGM_makeEdgeStruct(AdjMatrixOriginal, numStates);
    EdgeEnds = edgeStruct.edgeEnds;
    DataMatrix = [EdgeEnds (1:size(EdgeEnds, 1))'];
    AdjMatrixWithEdgeIds = MatrixTransformer.getPatternMatrix(DataMatrix, numNodes, numNodes);
    AdjMatrixWithEdgeIds = AdjMatrixWithEdgeIds + AdjMatrixWithEdgeIds';
    
    EdgeCouplings = zeros(numStates-1, (numStates-1)*(numNodes-1) + 1);
    groups = DiscreteRVGraphicalModel.getGroupIndices(numNodes, numStates);
    potentialNeighbors = [1:node-1, node+1:numNodes];
    edgeIds = AdjMatrixWithEdgeIds(node, potentialNeighbors);
    for possibleEdge = 1:numel(edgeIds)
        edgeId = edgeIds(possibleEdge);
        if(edgeId > 0)
            Values = log(EdgePotentials(1:numStates-1, 1:numStates-1, edgeId));
            EdgeCouplings(groups{1 + possibleEdge}) = Values(:);
        end
    end
end

function [SuccessMatrix] = getSuccessMatrix(edgeCouplings, numSamplesRange, sampleBatches, validationStr, sampleBatchesValidation, nodesToConsider, actualModel, optimizationOptions)
    import probabilisticModels.*;
    import graph.*;

    % process inputs
    AdjMatrixPartOriginal = actualModel.AdjMatrix(nodesToConsider, :);
    numEdgesOriginal = Graph.getNumEdges(AdjMatrixPartOriginal);
    [numStates, numNodes] = DiscreteRVGraphicalModel.countStatesAndNodes(edgeCouplings{nodesToConsider(1)});

    groups = DiscreteRVGraphicalModel.getGroupIndices(numNodes, numStates);

    c = DiscreteRVGraphicalModelLearner.learnConstantForGroupL1Factor(sampleBatchesValidation, nodesToConsider, validationStr, actualModel, optimizationOptions, edgeCouplings);

    function bSuccess = checkNbdRecovery(Samples)
        import probabilisticModels.*;
        import graph.*;
        [designMatrixParts, Rs] = DiscreteRVGraphicalModel.getDesignMatrixParts(Samples, numStates, optimizationOptions.bOrthogonalize);

        AdjMatrix = zeros(numNodes, numNodes);
        numSamples = size(Samples, 2);
        controlParam = DiscreteRVGraphicalModelLearner.controlParamForGroupL1Factor(numStates, numSamples, numNodes);
        fprintf('controlParam: %d\n', controlParam);
        for node = nodesToConsider

            % Learn graph
            % display('Paused'); pause
            groupL1Factor = c(node)*controlParam;
            [edgeCouplings{node}] = DiscreteRVGraphicalModelLearner.edgeCouplingsFromSamples(Samples, designMatrixParts, Rs, groupL1Factor, edgeCouplings{node}, optimizationOptions, node);

            AdjMatrix(node, :) = DiscreteRVGraphicalModel.getNeighborsFromEdgeCouplings(node, edgeCouplings{node});
            fprintf('node: %d, groupL1Factor: %d, numEdges: %d\n', node, groupL1Factor, sum(AdjMatrix(node, :)));
        end
        AdjMatrixPart = AdjMatrix(nodesToConsider, :);
        [extraEdges, extraEdgesInOriginal] = Graph.getDifference(AdjMatrixPart, AdjMatrixPartOriginal);
        numEdges = Graph.getNumEdges(AdjMatrixPart);
        fprintf('numEdges: %d, extraEdges: %d, extraEdgesInOriginal: %d\n', numEdges, extraEdges, extraEdgesInOriginal);
        bSuccess = (extraEdges + extraEdgesInOriginal == 0);
    
    end

    function bSuccessRow = checkNbdRecoveryRate(sampleBatches)
        bSuccessRow = zeros(1, numSampleSets);
        for(sampleSet = 1:numSampleSets)
            bSuccessRow(sampleSet) = checkNbdRecovery(sampleBatches{sampleSet});
        end
    end

    numSamplesRange = sort(numSamplesRange, 'descend');
    numSampleSets = length(sampleBatches);
    numSamplesRangeSize = numel(numSamplesRange);
    SuccessMatrix = false(numSamplesRangeSize, numSampleSets);
    for(numSamples = numSamplesRange)
        sampleBatches = DiscreteRVGraphicalModel.getSampleBatches(sampleBatches, numSamples);
        % keyboard
        SuccessMatrix((numSamplesRange == numSamples), :) = checkNbdRecoveryRate(sampleBatches);
    end
end

function controlParam = controlParamForGroupL1Factor(numStates, numSamples, numNodes)
    % Used in preliminary experiments:
    % controlParam = sqrt((numStates-1)*log(numNodes)/numSamples);
    controlParam = sqrt(log(numNodes - 1)/numSamples) + (numStates-1)/(4*sqrt(numSamples));
    %ALERT!!! TEMPORARY FIX, AS PRADEEP SUGGESTED.
    % controlParam = controlParam/numSamples;
end

function c = getCFromAlpha(alpha)
    c = 8*(2-alpha)/alpha;
end

function c = learnConstantForGroupL1Factor(sampleBatches, nodesToConsider, validationStr, actualModel, optimizationOptions, edgeCouplings)
    import probabilisticModels.*;
    AdjMatrixPartOriginal = actualModel.AdjMatrix(nodesToConsider, :);
    numNodes = size(AdjMatrixPartOriginal, 2);

    %% Determine validation type.
    cRange = [.15:0.05:0.5];


    c = zeros(numNodes, 1);

    function cBest = binarySearchForGroupL1Factor(sampleBatches, EdgeCouplingsInit, optimizationOptions, numEdgesOriginal, cRange, nodeToFocusOn)
        %validation to learn groupL2FactorBest
        import probabilisticModels.*;
        import graph.*;
        import optimization.*;
        fprintf('Doing binary search, numEdgesOriginal: %d\n', numEdgesOriginal);

        numSampleSetsForValidation = length(sampleBatches);
        designMatrixPartBatches = {};
        RBatches = {};
        [numStates, numNodes] = DiscreteRVGraphicalModel.countStatesAndNodes(EdgeCouplingsInit);
        groups = DiscreteRVGraphicalModel.getGroupIndices(numNodes, numStates);


        [designMatrixPartBatches, RBatches] = DiscreteRVGraphicalModel.getDesignMatrixPartBatches(sampleBatches, numStates, optimizationOptions.bOrthogonalize);

        graphFromSamplesFn = @(groupL1Factor, i, EdgeCouplings) DiscreteRVGraphicalModelLearner.edgeCouplingsFromSamples(sampleBatches{i}, designMatrixPartBatches{i}, RBatches{i}, groupL1Factor, EdgeCouplings, optimizationOptions, nodeToFocusOn);

        EdgeCouplingsEvalFn = @(EdgeCouplings, i) -Graph.getNumEdges(DiscreteRVGraphicalModel.getNeighborsFromEdgeCouplings(nodeToFocusOn, EdgeCouplings))+ numEdgesOriginal;

        function [objVal, EdgeCouplings] = tmpFn1(c, i, EdgeCouplings, graphFromSamplesFn, EdgeCouplingsEvalFn, numStates, numNodes)
            import probabilisticModels.*;
            numSamples = size(sampleBatches{i}, 2);
            controlParam = DiscreteRVGraphicalModelLearner.controlParamForGroupL1Factor(numStates, numSamples, numNodes);
            EdgeCouplings = graphFromSamplesFn(c*controlParam, i, EdgeCouplings);
            objVal = EdgeCouplingsEvalFn(EdgeCouplings, i);
        end

        objFn = @(c, i, EdgeCouplings)tmpFn1(c, i, EdgeCouplings, graphFromSamplesFn, EdgeCouplingsEvalFn, numStates, numNodes);

        objFnAvg = @(c)mean(MatrixFunctions.functionalToEachColumn([1:numSampleSetsForValidation], @(i, initParams)objFn(c, i, initParams), EdgeCouplingsInit));

        val_tgt = 0;
        cBest = GlobalOptimization.binarySearch(min(cRange), max(cRange), objFnAvg, val_tgt);
    end

    function cBest = getMinScore_c(sampleBatches, EdgeCouplings, optimizationOptions, evalFn, cRange, node)
        import probabilisticModels.*;
        cRange = sort(cRange, 'descend');
        numSampleSets = length(sampleBatches);
        [numStates, numNodes] = DiscreteRVGraphicalModel.countStatesAndNodes(EdgeCouplings);

        [designMatrixPartBatches, RBatches] = DiscreteRVGraphicalModel.getDesignMatrixPartBatches(sampleBatches, numStates, optimizationOptions.bOrthogonalize);

        graphFromSamplesFn = @(groupL1Factor, i, EdgeCouplings) DiscreteRVGraphicalModelLearner.edgeCouplingsFromSamples(sampleBatches{i}, designMatrixPartBatches{i}, RBatches{i}, groupL1Factor, EdgeCouplings, optimizationOptions, node);


        function [objVal, EdgeCouplings] = tmpFn1(c, EdgeCouplings)
            import probabilisticModels.*;
            objValTmp = [];
            for(i = 1:numSampleSets)
                numSamples = size(sampleBatches{i}, 2);
                controlParam = DiscreteRVGraphicalModelLearner.controlParamForGroupL1Factor(numStates, numSamples, numNodes);
                EdgeCouplings = graphFromSamplesFn(c*controlParam, i, EdgeCouplings);
                objValTmp(end+1) = evalFn(EdgeCouplings);
            end
            objVal = mean(objValTmp);
        end

        scores = MatrixFunctions.functionalToEachColumn(cRange, @tmpFn1, EdgeCouplings);
        scores
        cRange
        % It is possible that multiple c's have the same score.
        cBest = mean(cRange(scores == min(scores)));
    end


    function score = edgeCouplingsEvalFn(EdgeCouplings, adjMatrixRowOriginal)
        import graph.*;
        import probabilisticModels.*;
        [extraNodesA, extraNodesB] = Graph.getDifference(adjMatrixRowOriginal, DiscreteRVGraphicalModel.getNeighborsFromEdgeCouplings(node, EdgeCouplings));
        score = extraNodesA + extraNodesB;
    end

    function c = getHardcoded_c()
        fprintf('Using hardcoded values for c.\n');
        switch(numNodes)
        case 3
            % c(node) = 0.145; % No devious thresholding necessary for this choice.
            c(node) = 0.05;
            % c(node) = 0.0;
        case 16
            c(node) = 0.15;
            return;

            switch(actualModel.topology)
                case 'chain'
                    % c = 0.3;
                    c(node) = 0.15;
                case 'grid'
                    c = zeros(numNodes, 1);
                    c(:) = 0.876;
                    c([1,4,13, 16]) = .414;
                    c([2, 3, 5, 8, 9, 12, 14, 15]) = 0.293;
                    return;
            end
        end
    end
    
    for(node = nodesToConsider)
        EdgeCouplings = edgeCouplings{node};
        adjMatrixRowOriginal = AdjMatrixPartOriginal(nodesToConsider == node, :);
        if(~exist('validationStr') || length(validationStr) == 0)
            c(node) = DiscreteRVGraphicalModelLearner.getCFromAlpha(actualModel.alpha);
        elseif(StringUtilities.isSubstring(validationStr, 'OldExp'))
            c = getHardcoded_c();
        elseif(StringUtilities.isSubstring(validationStr, 'binary'))
            fprintf(' Doing binary search.\n');
            cRange = [0, max(cRange)];
            c(node) = binarySearchForGroupL1Factor(sampleBatches, EdgeCouplings, optimizationOptions, full(sum(adjMatrixRowOriginal)), cRange, node);
        elseif(StringUtilities.isSubstring(validationStr, 'Likelihood'))
            fprintf(' Doing max likelihood.\n');
            [numStates, numNodes] = DiscreteRVGraphicalModel.countStatesAndNodes(EdgeCouplings);
            numSamplesRange = cellfun(@(S)size(S, 2), sampleBatches);
            maxSetIndex = find(numSamplesRange == max(numSamplesRange));
            maxSetIndex = maxSetIndex(1);
            ValidationSamples = sampleBatches{maxSetIndex};
            sampleBatches = sampleBatches([1:maxSetIndex-1 maxSetIndex+1:length(sampleBatches)]);
            
            [designMatrixParts Rs] = DiscreteRVGraphicalModel.getDesignMatrixParts(ValidationSamples, numStates, false);
            [X, y] = DiscreteRVGraphicalModelLearner.getObservationsForLogisticRegression(designMatrixParts, ValidationSamples, node);
            
            potentialNeighbors = [1:node-1, node+1:numNodes];
            avgNegLogLikelihoodFn = @(B)LogisticMultiClassL1L2Reg.getAvgNegLogLikelihoodWithDerivatives(X, y, B);
            c(node) = getMinScore_c(sampleBatches, EdgeCouplings, optimizationOptions, avgNegLogLikelihoodFn, cRange, node);
        else
            fprintf(' Doing min-edge-disagreement.\n');
            c(node) = getMinScore_c(sampleBatches, EdgeCouplings, optimizationOptions, @(B)edgeCouplingsEvalFn(B, adjMatrixRowOriginal), cRange, node);
            % error('Not implemented');
        end
     end
    fprintf('Best c: ');
    c'
end

function [model] = checkModelLearnability(edgeCouplings, Samples, model, nodesToConsider)
    display 'Checking learnability';
    import probabilisticModels.*;
    AdjMatrix = model.AdjMatrix;
    model.bLearnability = true;
    [numStates, numNodes] = DiscreteRVGraphicalModel.countStatesAndNodes(edgeCouplings{nodesToConsider(1)});
    [designMatrixParts Rs] = DiscreteRVGraphicalModel.getDesignMatrixParts(Samples, numStates, false);
    
    groups = DiscreteRVGraphicalModel.getGroupIndices(numNodes, numStates);
    EventMatrix = [designMatrixParts{1:numNodes}]';
    CooccuranceProbability = statistics.Estimation.estimateCooccuranceProbabilities(EventMatrix);
    
    function [ew_min, incoherence, ew_max_XX] = checkNbdLearnability(node)
        import probabilisticModels.*;
        EdgeCouplings = edgeCouplings{node};
        adjMatrixRow = AdjMatrix(node, :);
        [X, y] = DiscreteRVGraphicalModelLearner.getObservationsForLogisticRegression(designMatrixParts, Samples, node);
        
        [nll, avgGradientNegLogLikelihood, avgHessianDiagNegLogLikelihood, ExpectedHessianNll] = LogisticMultiClassL1L2Reg.getAvgNegLogLikelihoodWithDerivatives(X, y, EdgeCouplings);

        % keyboard

        dim = size(X, 1);
        potentialNeighbors = [1:node-1, node+1:numNodes];
        nbdSet = find(adjMatrixRow(potentialNeighbors));
        nonNbdSet = find(~adjMatrixRow(potentialNeighbors));
        function indexTemplate = getIndexTemplate(nodeSet)
            indexTemplate = zeros(dim, 1);
            for neighbor = nodeSet
                tmp = groups{1 + neighbor};
                tmp = tmp(1, :);
                indexTemplate = indexTemplate | tmp';
            end
        end
        
        nbdSetIndex = kron(ones(numStates-1, 1), getIndexTemplate(nbdSet));
        nbdSetIndex = logical(nbdSetIndex);

        % The below yields error sometimes.
        % ew_min = eigs(ExpectedHessianNll(nbdSetIndex, nbdSetIndex), 1, 'SM');
        [V, D] = eig(ExpectedHessianNll(nbdSetIndex, nbdSetIndex));
        ew_min = min(diag(D));
        
        nonNbdSetIndex = kron(ones(numStates-1, 1), getIndexTemplate(nonNbdSet));
        nonNbdSetIndex = logical(nonNbdSetIndex);
        Tmp = ExpectedHessianNll(nonNbdSetIndex, nbdSetIndex)/ExpectedHessianNll(nbdSetIndex, nbdSetIndex);
        incoherence = norm(Tmp, 'inf');
        if(isnan(incoherence))
            warning('incoherence is nan! Probably the edgeCouplings had nan values, and edgePotentials had Inf values.');
            Tmp
            keyboard
        end

        tmp = zeros(numNodes, 1);
        tmp(potentialNeighbors) = 1;
        nbdIndices = kron(tmp, ones(numStates-1, 1));
        % keyboard
        nbdIndices = logical(nbdIndices);
        CooccuranceProbabilityOtherNodes = CooccuranceProbability(nbdIndices, nbdIndices);
        % CooccuranceProbabilityOtherNodes
        ew_max_XX = eigs(CooccuranceProbabilityOtherNodes, 1, 'LM');
    end
    model.ew_minBound = +Inf;
    model.incoherenceBound = -Inf;
    model.ew_max_XXBound = -Inf;

    for(node = nodesToConsider)
        [ew_min, incoherence, ew_max_XX] = checkNbdLearnability(node);
        
        model.ew_minBound = min([model.ew_minBound, ew_min]);
        model.incoherenceBound = max([incoherence, model.incoherenceBound]);
        model.ew_max_XXBound = max([model.ew_max_XXBound, ew_max_XX]);
        fprintf('ew_min: %d, incoherence: %d, ew_max_XX: %d\n', ew_min, incoherence, ew_max_XX);
    end
    fprintf('ew_minBound: %d, incoherenceBound: %d, ew_max_XXBound: %d\n', model.ew_minBound, model.incoherenceBound, model.ew_max_XXBound);

    %% Note that alpha's relation with the population Fisher Information Matrix is different from its relation with the sample FIsher information matrix.
    model.alpha = (1-model.incoherenceBound);
    if(model.alpha <= 0)
        warning('Invalid alpha: %d!\n', model.alpha);
        model.bLearnability = false;
        % error('Invalid alpha!');
    end

    numSamplesMin = 50;
    lambdaMax = DiscreteRVGraphicalModelLearner.getCFromAlpha(model.alpha)*DiscreteRVGraphicalModelLearner.controlParamForGroupL1Factor(numStates, numSamplesMin, numNodes);

    numSamplesMax = 2^13;
    lambdaMin = DiscreteRVGraphicalModelLearner.getCFromAlpha(model.alpha)*DiscreteRVGraphicalModelLearner.controlParamForGroupL1Factor(numStates, numSamplesMax, numNodes);

%      if(10*lambdaMax/model.ew_minBound > (max(model.couplingRange)))
%          warning('10*lambdaMax/model.ew_minBound is too big: %d!\n', 10*lambdaMax/model.ew_minBound);
%          10*lambdaMax/model.ew_minBound
%          max(model.couplingRange)
%          model.bLearnability = false;
%          % error('Edge recovery not possible!');
%      end
%      if(10*lambdaMin/model.ew_minBound > (max(model.couplingRange)))
%          warning('10*lambdaMin/model.ew_minBound is too big: %d!\n', 10*lambdaMin/model.ew_minBound);
%          10*lambdaMin/model.ew_minBound
%          max(model.couplingRange)
%          model.bLearnability = false;
%          % error('Edge recovery not possible!');
%      end
end

function testNbdFromSamples(numNodesOrFileName, topology, nodesToConsider, experimentMode)
    % INPUT:
    %  experimentMode: Choices below are described using regular expressions.
    %      'parallelPrepare-VALIDATION' - Prepare a parallel experiment. VALIDATION is one of the validation choices described below.
    %      'parallelRun-VALIDATION' - Run a parallel experiment, parallel. VALIDATION is one of the validation choices described below.
    %      'parallelCombine-VALIDATION' - combine the results from several parallel runs.
    %     Validation choices:
    %      ''
    %      '*Binary*' - Use binary search.
    %      '*Likelihood*' - Use max-likelihood.
    %      '.+' - (Any non-empty string different from the above.) Use minimum edge disagreement.
    
    import probabilisticModels.*;
    import graph.*;


    if(~exist('experimentMode'))
        experimentMode = '';
    end
    
    %% Get probability of success plot
    numSamplesRange = 2.^[6:12];
    numSamplesRange = sort(numSamplesRange, 'descend');
    numSampleSets = 15;

    % Get samples
    %% Prepare the sample batches for validation
    function [sampleBatches, sampleBatchesValidation] = getSampleBatches(actualModel)
        sampleBatchGeneratorFn = @(numSamples, numSampleSets, sampleBatches)DiscreteRVGraphicalModel.getSampleBatches(sampleBatches, numSamples, numSampleSets, actualModel);

        timerTmp = Timer();
        sampleBatches = {};
        sampleBatches = sampleBatchGeneratorFn(max(numSamplesRange), numSampleSets, sampleBatches);
        timerTmp.endTimer();

        sampleBatchesValidation = {};
        if(length(experimentMode) > 0)
            numSamplesRangeValidation = 2.^[11:13];
            sample = {};
            for(numSamples = numSamplesRangeValidation)
                sample = sampleBatchGeneratorFn(numSamples, 1, {});
                sampleBatchesValidation{end+1} = sample{1};
            end
        end
    end

    function [strB] = appendNodeFocusDetails(strB, nodesToConsider)
        if(length(nodesToConsider) == 1)
            strB = [strB '-' num2str(nodesToConsider) 'nd'];
        end
    end

    function [actualModel, edgeCouplings] = testModelAndGetEdgeCouplings(actualModel)
        import probabilisticModels.*;
        for node = nodesToConsider
            edgeCouplings{node} = DiscreteRVGraphicalModelLearner.getInitEdgeCouplings(actualModel, node);
            % edgeCouplings{node}
        end
        % log(actualModel.EdgePotentials)
        if(~StringUtilities.isSubstring(experimentMode, 'parallelRun') && ~StringUtilities.isSubstring(experimentMode, 'parallelCombine'))
            TmpSamples = DiscreteRVGraphicalModel.getSamples(actualModel, 2^12);
            [actualModel] = DiscreteRVGraphicalModelLearner.checkModelLearnability(edgeCouplings, TmpSamples, actualModel, nodesToConsider);
        end
    end
    
    function [actualModel, experimentName, sampleBatches, sampleBatchesValidation, edgeCouplings] = getRandomGraphicalModel(numNodes, topology, nodesToConsider, sampleBatches, sampleBatchesValidation)
        import probabilisticModels.*;
        %% Get graphical model.
        numStates = 3;
        % numStates = numNodes;
        degmax = [];
        disparityLevel = 0;
        minCoupling = 1;
        couplingType = 'uniform';
        if(~exist('topology', 'var') || isempty(topology))
            % topology = 'chain';
            topology = 'star';
        end
        %% Set up penalty type.
        if(~exist('groupL1penaltyType') || isempty(groupL1penaltyType))
            groupL1penaltyType = 'L1L2';
            % groupL1penaltyType = 'L1L2Lagrangian';
            % groupL1penaltyType = 'L1L_inf';
        end

        actualModel.ew_minBound = .02;
        % for c = 10:10:100
           % numSamplesMin = 50;
           % lambdaMax = c*DiscreteRVGraphicalModelLearner.controlParamForGroupL1Factor(numStates, numSamplesMin, numNodes);
            
           % minCoupling = 10*lambdaMax/actualModel.ew_minBound;
           % minCoupling = c;
           % fprintf('c: %d, lambdaMax:%d, actualModel.ew_minBound: %d, minCoupling: %d \n', c, lambdaMax, actualModel.ew_minBound, minCoupling);
        for minCoupling = 0.5
            [actualModel] = DiscreteRVGraphicalModel.getDiscreteRVGraphicalModel(topology, numNodes, degmax, numStates, couplingType, disparityLevel, minCoupling);
            [actualModel, edgeCouplings] = testModelAndGetEdgeCouplings(actualModel);
            if(actualModel.bLearnability)
                break;
            end
        end
        if(~actualModel.bLearnability)
            error('Could not find a learnable model!');
        end

        experimentName = [actualModel.topology num2str(numNodes) 'n-' num2str(actualModel.couplingRange(1)) ':' num2str(actualModel.couplingRange(2)) actualModel.couplingType groupL1penaltyType];
        experimentName = appendNodeFocusDetails(experimentName, nodesToConsider);

        % log(EdgePotentials)
        [sampleBatches, sampleBatchesValidation] = getSampleBatches(actualModel);
    end

    function [actualModel, experimentName, sampleBatches, sampleBatchesValidation, edgeCouplings] = loadGraphicalModelFromFile(fileNameSansExtension)
        import probabilisticModels.*;
        
        if(StringUtilities.isSubstring(experimentMode, 'parallelRun'))
            fullFileNameSansExtension = [gmStructureLearningExperiments.Constants.TMP_PATH fileNameSansExtension];
        else
            fullFileNameSansExtension = [gmStructureLearningExperiments.Constants.LOG_PATH fileNameSansExtension];
        end
        load(fullFileNameSansExtension);
        if(~exist('experimentName'))
            experimentName = fileNameSansExtension(1:strfind(fileNameSansExtension, '2010')-1);
        end
        [actualModel, edgeCouplings] = testModelAndGetEdgeCouplings(actualModel); if(~exist('sampleBatches'))
            [sampleBatches, sampleBatchesValidation] = getSampleBatches(actualModel);
        end
    end


    if(length(numNodesOrFileName)>1)
        fileNameSansExtension = numNodesOrFileName;
        [actualModel, experimentName, sampleBatches, sampleBatchesValidation, edgeCouplings] = loadGraphicalModelFromFile(fileNameSansExtension);
    else
        [actualModel, experimentName, sampleBatches, sampleBatchesValidation, edgeCouplings] = getRandomGraphicalModel(numNodesOrFileName, topology, nodesToConsider);
    end
    % keyboard

    if(StringUtilities.isSubstring(experimentMode, 'parallelPrepare'))
        dataFile = [gmStructureLearningExperiments.Constants.TMP_PATH experimentName '-parallelPrepare' Timer.getTimeStamp()];
        %% Append experiment details (adjascency matrix, couplings) to mat file.
        save([dataFile '.mat'],'actualModel', 'experimentName', 'sampleBatches', 'sampleBatchesValidation', 'nodesToConsider');

        experimentModeForCommand = strrep(experimentMode, 'parallelPrepare', 'parallelRun');
        commandFileName = [dataFile '-parallelCommands.sh'];
        commandFileName
        commandFile = fopen(commandFileName, 'w');
        for(node = nodesToConsider)
            machineName = sprintf('uvanimor-%d', mod(node, 9));
            outputFileNameStub = strrep(dataFile, 'parallelPrepare', 'parallelResults');
            outputFileNameStub = appendNodeFocusDetails(outputFileNameStub, node);
            commandOutputFile = [outputFileNameStub '.out'];
            commandErrorFile = [outputFileNameStub '.err'];
            matlabScriptCreation = sprintf('echo "probabilisticModels.DiscreteRVGraphicalModelLearner.testNbdFromSamples\\(''%s'',''%s'', %d, ''%s''\\)">>/tmp/script.m', dataFile, topology, node, experimentModeForCommand);
            fprintf(commandFile, '%s; ssh %s "matlab -nodisplay -nosplash -nojvm</tmp/script.m" >>%s\n', matlabScriptCreation, machineName, commandOutputFile);
        end
        fclose(commandFile);
        system(['chmod a+x ' commandFileName]);
        
        % error('Run parallel condor experiments');
        return;
    end
    
    optimizationOptions.stoppingThreshold = 10^-5;
    optimizationOptions.bOrthogonalize = false;
    function threshold = thresholdingRule(groupL1Factor)
        % threshold = groupL1Factor/actualModel.ew_minBound;
        % threshold = groupL1Factor;
        threshold = max(actualModel.couplingRange)/3;
    end
    optimizationOptions.thresholdingFn = @thresholdingRule;

    if(StringUtilities.isSubstring(experimentMode, 'parallel'))
        resultsFile = strrep(fileNameSansExtension, 'parallelPrepare', 'parallelResults');
    end

    function [SuccessMatrix] = getStoredSuccessMatrix(node)
        resultsFile = appendNodeFocusDetails(resultsFile, node);
        load(resultsFile);
    end

    if(StringUtilities.isSubstring(experimentMode, 'parallelCombine'))
        SuccessMatrix = getStoredSuccessMatrix(1);
        numNodes = size(AdjMatrixOriginal, 1);
        for(node = 2:numNodes)
            SuccessMatrix = SuccessMatrix & getStoredSuccessMatrix(node);
        end
    else
        timer = Timer();
        [SuccessMatrix] = DiscreteRVGraphicalModelLearner.getSuccessMatrix(edgeCouplings, numSamplesRange, sampleBatches, experimentMode, sampleBatchesValidation, nodesToConsider, actualModel, optimizationOptions);
        timer.endTimer();
        
        if(StringUtilities.isSubstring(experimentMode, 'parallelRun'))
            resultsFile = appendNodeFocusDetails(resultsFile, nodesToConsider);
            save([resultsFile '.mat'], 'SuccessMatrix', 'nodesToConsider');
            return;
        end
    end
    
    function [fullFileNameSansExtension, probabilitiesOfSuccess] = plotProbabilitySuccess()
        probabilitiesOfSuccess = sum(SuccessMatrix, 2)/ numSampleSets;
        [figureHandle, fullFileNameSansExtension] = IO.plotAndSave(numSamplesRange(1:numel(probabilitiesOfSuccess)), probabilitiesOfSuccess, 'numSamples', 'Prob. of success',  gmStructureLearningExperiments.Constants.LOG_PATH, experimentName, '');

        %% Append experiment details (adjascency matrix, couplings) to mat file.
        save([fullFileNameSansExtension '.mat'],'actualModel', 'experimentName', 'nodesToConsider', 'experimentMode', 'c', '-append');
        if(exist('topology'))
            save([fullFileNameSansExtension '.mat'], 'topology', '-append');
        end
    end
    
    [fullFileNameSansExtension, probabilitiesOfSuccess] = plotProbabilitySuccess();
    fprintf('All done: ready for inspection!\n');
    keyboard

end

function testClass
    display 'Class definition is ok';
end

end
end
